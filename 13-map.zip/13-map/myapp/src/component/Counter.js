function Counter({countProps}) {
    return <h1>Total click: {countProps}</h1>
}
export default Counter