const Card = () => {
    return (
        <>
        <h1>Student</h1>
        <h3>I am studying a course on React</h3>
        <button>Like!</button>
        </>
    )
}
export default Card