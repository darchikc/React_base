function OtherComponent() {
    return (
    <div>
        <h1> from the reusable component</h1>
        <button>Like!</button>
    </div>
    )
}

export default OtherComponent