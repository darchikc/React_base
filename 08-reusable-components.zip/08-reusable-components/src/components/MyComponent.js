function MyComponent() {
    return (
    <div>
        <h1>Hello from the reusable component</h1>
        <button>Like!</button>
    </div>
    )
}

export default MyComponent